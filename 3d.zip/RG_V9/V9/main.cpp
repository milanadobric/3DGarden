﻿#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

const float GROUND_EXTENT = 7.0f;
float       plantScale = 1.0f;
float       rotate = 0.0f;
bool        usePerspective = true;
bool        showRow[3] = { true, true, true };

const float SCALE_STEP = 0.07f;
const float ROTATE_ANGLE_STEP = 0.5f;

unsigned int compileShader(GLenum type, const char* source)
{
    std::ifstream file(source);
    std::stringstream ss;
    if (file.is_open())
    {
        ss << file.rdbuf();
        file.close();
        std::cout << "Uspjesno procitao fajl sa putanje \"" << source << "\"!" << std::endl;
    }
    else {
        ss << "";
        std::cout << "Greska pri citanju fajla sa putanje \"" << source << "\"!" << std::endl;
    }
    std::string temp = ss.str();
    const char* sourceCode = temp.c_str();

    int shader = glCreateShader(type);

    int success;
    char infoLog[512];
    glShaderSource(shader, 1, &sourceCode, NULL);
    glCompileShader(shader);

    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
    if (success == GL_FALSE)
    {
        glGetShaderInfoLog(shader, 512, NULL, infoLog);
        if (type == GL_VERTEX_SHADER)
            printf("VERTEX");
        else if (type == GL_FRAGMENT_SHADER)
            printf("FRAGMENT");
        printf(" sejder ima gresku! Greska: \n");
        printf(infoLog);
    }
    return shader;
}
unsigned int createShader(const char* vsSource, const char* fsSource)
{
    unsigned int program;
    unsigned int vertexShader;
    unsigned int fragmentShader;

    program = glCreateProgram();

    vertexShader = compileShader(GL_VERTEX_SHADER, vsSource);
    fragmentShader = compileShader(GL_FRAGMENT_SHADER, fsSource);

    glAttachShader(program, vertexShader);
    glAttachShader(program, fragmentShader);

    glLinkProgram(program);
    glValidateProgram(program);

    int success;
    char infoLog[512];
    glGetProgramiv(program, GL_VALIDATE_STATUS, &success);
    if (success == GL_FALSE)
    {
        glGetShaderInfoLog(program, 512, NULL, infoLog);
        std::cout << "Objedinjeni sejder ima gresku! Greska: \n";
        std::cout << infoLog << std::endl;
    }

    glDetachShader(program, vertexShader);
    glDeleteShader(vertexShader);
    glDetachShader(program, fragmentShader);
    glDeleteShader(fragmentShader);

    return program;
}
void framebuffer_size_callback(GLFWwindow* win, int w, int h) {
    glViewport(0, 0, w, h);
}



void processInput(GLFWwindow* win) {
    if (glfwGetKey(win, GLFW_KEY_W) == GLFW_PRESS)
        plantScale += SCALE_STEP;
    if (glfwGetKey(win, GLFW_KEY_S) == GLFW_PRESS)
        plantScale = glm::max(0.1f, plantScale - SCALE_STEP);
    if (glfwGetKey(win, GLFW_KEY_A) == GLFW_PRESS)
        rotate -= ROTATE_ANGLE_STEP;
    if (glfwGetKey(win, GLFW_KEY_D) == GLFW_PRESS)
        rotate += ROTATE_ANGLE_STEP;
    if (glfwGetKey(win, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(win, true);
}

void key_callback(GLFWwindow* win, int key, int sc, int act, int mods) {
    if (act != GLFW_PRESS) return;
    if (key == GLFW_KEY_1) showRow[0] = !showRow[0];
    if (key == GLFW_KEY_2) showRow[1] = !showRow[1];
    if (key == GLFW_KEY_3) showRow[2] = !showRow[2];
    if (key == GLFW_KEY_O) usePerspective = false;
    if (key == GLFW_KEY_P) usePerspective = true;
}


int main() {
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    GLFWwindow* window = glfwCreateWindow(800, 600, "3D Garden", nullptr, nullptr);
    glfwMakeContextCurrent(window);
    glewExperimental = GL_TRUE;
    glewInit();


    int texWidth, texHeight, texChannels;
    stbi_set_flip_vertically_on_load(true);
    unsigned char* image = stbi_load("signature.png", &texWidth, &texHeight, &texChannels, STBI_rgb_alpha);


    if (!image) {
        std::cerr << "Greska: Ne mogu da ucitam sliku signature.png!" << std::endl;
    }


    GLuint textTex;
    glGenTextures(1, &textTex);
    glBindTexture(GL_TEXTURE_2D, textTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, texWidth, texHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    stbi_image_free(image);


    float sigQuad[] = {
        // pos       // tex
        10.0f, 10.0f,   0.0f, 0.0f,
        266.0f, 10.0f,  1.0f, 0.0f,
        266.0f, 42.0f,  1.0f, 1.0f, 
        10.0f, 42.0f,   0.0f, 1.0f
    };
    unsigned int sigIndices[] = { 0, 1, 2, 2, 3, 0 };

    GLuint sigVAO, sigVBO, sigEBO;
    glGenVertexArrays(1, &sigVAO);
    glGenBuffers(1, &sigVBO);
    glGenBuffers(1, &sigEBO);

    glBindVertexArray(sigVAO);
    glBindBuffer(GL_ARRAY_BUFFER, sigVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(sigQuad), sigQuad, GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, sigEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(sigIndices), sigIndices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)(2 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glBindVertexArray(0);




    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetKeyCallback(window, key_callback);

    glfwSwapInterval(1);

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);



    unsigned int shaderProgram = createShader("basic.vert", "basic.frag");
    unsigned int imgShader = createShader("img.vert", "img.frag");
    int img_uP = glGetUniformLocation(imgShader, "uP");

    int locM = glGetUniformLocation(shaderProgram, "uM");
    int locV = glGetUniformLocation(shaderProgram, "uV");
    int locP = glGetUniformLocation(shaderProgram, "uP");

    float groundVerts[] = {
        -GROUND_EXTENT, 0, -GROUND_EXTENT,   
        -GROUND_EXTENT, 0,  GROUND_EXTENT,   
         GROUND_EXTENT, 0,  GROUND_EXTENT,   

         -GROUND_EXTENT, 0, -GROUND_EXTENT,   
          GROUND_EXTENT, 0,  GROUND_EXTENT,   
          GROUND_EXTENT, 0, -GROUND_EXTENT    
    };



    float quadVerts[] = {
        -0.5f,0,0,  0.5f,0,0,  0.5f,1,0,
        -0.5f,0,0,  0.5f,1,0, -0.5f,1,0
    };

    GLuint groundVAO, groundVBO;
    glGenVertexArrays(1, &groundVAO);
    glGenBuffers(1, &groundVBO);
    glBindVertexArray(groundVAO);
    glBindBuffer(GL_ARRAY_BUFFER, groundVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(groundVerts), groundVerts, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    GLuint quadVAO, quadVBO;
    glGenVertexArrays(1, &quadVAO);
    glGenBuffers(1, &quadVBO);
    glBindVertexArray(quadVAO);
    glBindBuffer(GL_ARRAY_BUFFER, quadVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(quadVerts), quadVerts, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    std::vector<glm::vec3> plantPos[3];
    for (int r = 0; r < 3; ++r) {
        float z = (r - 1) * 4.0f;
        for (int i = -2; i <= 2; ++i)
            plantPos[r].push_back(glm::vec3(i * 2.0f, 0.0f, z));
    }

    while (!glfwWindowShouldClose(window)) {
        processInput(window);
        glClearColor(0.5f, 0.8f, 0.9f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glm::vec3 camPos(0.0f, 3.0f, 15.0f);
        glm::mat4 view = glm::lookAt(camPos, glm::vec3(0), glm::vec3(0, 1, 0));
        view = glm::rotate(view, glm::radians(-rotate), glm::vec3(0, 1, 0));


        int w, h;
        glfwGetFramebufferSize(window, &w, &h);
        float aspect = float(w) / float(h);
        glm::mat4 proj = usePerspective
            ? glm::perspective(glm::radians(45.0f), aspect, 0.1f, 100.0f)
            : glm::ortho(-GROUND_EXTENT * aspect, GROUND_EXTENT * aspect,
                -GROUND_EXTENT, GROUND_EXTENT,
                0.1f, 100.0f);

        glUseProgram(shaderProgram);
        glUniformMatrix4fv(locV, 1, GL_FALSE, &view[0][0]);
        glUniformMatrix4fv(locP, 1, GL_FALSE, &proj[0][0]);

        glVertexAttrib4f(1, 0.0f, 0.3f, 0.0f, 1.0f);
        glm::mat4 Mground(1.0f);
        glUniformMatrix4fv(locM, 1, GL_FALSE, &Mground[0][0]);
        glEnable(GL_CULL_FACE);
        glBindVertexArray(groundVAO);
        glDrawArrays(GL_TRIANGLES, 0, 6);

        glDisable(GL_CULL_FACE);
        glBindVertexArray(quadVAO);
        for (int r = 0; r < 3; ++r) {
            if (!showRow[r]) continue;
            glm::vec3 col = (r == 0 ? glm::vec3(0.2f, 0.8f, 0.2f) :
                r == 1 ? glm::vec3(0.9f, 0.6f, 0.1f) : glm::vec3(0.6f, 0.3f, 0.7f));
            glVertexAttrib4f(1, col.r, col.g, col.b, 1.0f);
            for (auto& p : plantPos[r]) {
                glm::mat4 M1 = glm::translate(glm::mat4(1.0f), p);
                M1 = glm::scale(M1, glm::vec3(plantScale));
                glUniformMatrix4fv(locM, 1, GL_FALSE, &M1[0][0]);
                glDrawArrays(GL_TRIANGLES, 0, 6);
                glm::mat4 M2 = glm::translate(glm::mat4(1.0f), p);
                M2 = glm::scale(M2, glm::vec3(plantScale));
                M2 = glm::rotate(M2, glm::radians(90.0f), glm::vec3(0, 1, 0));
                glUniformMatrix4fv(locM, 1, GL_FALSE, &M2[0][0]);
                glDrawArrays(GL_TRIANGLES, 0, 6);
            }
        }
        glEnable(GL_CULL_FACE);

        glUseProgram(imgShader);
        glm::mat4 ortho = glm::ortho(0.0f, (float)w, 0.0f, (float)h);
        glUniformMatrix4fv(img_uP, 1, GL_FALSE, &ortho[0][0]);

        glBindTexture(GL_TEXTURE_2D, textTex);
        glBindVertexArray(sigVAO);
        glDisable(GL_DEPTH_TEST);

        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
        glEnable(GL_DEPTH_TEST);


        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glDeleteProgram(shaderProgram);
    glDeleteVertexArrays(1, &groundVAO);
    glDeleteBuffers(1, &groundVBO);
    glDeleteVertexArrays(1, &quadVAO);
    glDeleteBuffers(1, &quadVBO);
    glDeleteVertexArrays(1, &sigVAO);
    glDeleteBuffers(1, &sigVBO);
    glDeleteBuffers(1, &sigEBO);
    glDeleteTextures(1, &textTex);
    glDeleteProgram(imgShader);
    glfwTerminate();
    return 0;
}
